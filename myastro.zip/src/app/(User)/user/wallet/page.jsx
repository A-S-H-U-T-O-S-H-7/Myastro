import WalletSection from '@/components/WalletSection'
import React from 'react'

const page = () => {
  return (
    <div>
      <WalletSection/>
    </div>
  )
}

export default page
