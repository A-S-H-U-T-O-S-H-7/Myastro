import PaymentSection from '@/components/PaymentSection'
import React from 'react'

const page = () => {
  return (
    <div>
      <PaymentSection/> 
    </div>
  )
}

export default page
