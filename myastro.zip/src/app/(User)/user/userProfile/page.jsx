import React from 'react'
import UserProfileInput from '@/components/UserProfileInput'

const UserProfile = () => {
  return (
    <div>
      <UserProfileInput/>
      
    </div>
  )
}

export default UserProfile
