import RejectedAstrologer from '@/components/Admin/RejectedAstrologer'
import React from 'react'

function page() {
  return (
    <div>
      <RejectedAstrologer/>
    </div>
  )
}

export default page
