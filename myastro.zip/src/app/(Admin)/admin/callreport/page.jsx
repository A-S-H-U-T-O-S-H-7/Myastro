import React from 'react'
import CallReport from '@/components/Admin/CallReport'

function page() {
  return (
    <div>
      <CallReport/>
    </div>
  )
}

export default page
