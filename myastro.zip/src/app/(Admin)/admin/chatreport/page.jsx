import React from 'react'
import ChatReport from '@/components/Admin/ChatReport'

function page() {
  return (
    <div>
      <ChatReport/>
    </div>
  )
}

export default page
