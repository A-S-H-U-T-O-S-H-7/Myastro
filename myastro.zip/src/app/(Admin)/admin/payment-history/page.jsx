import PaymentHistory from '@/components/Admin/PaymentHistory'
import React from 'react'

function page() {
  return (
    <div>
      <PaymentHistory/>
    </div>
  )
}

export default page
