import ApprovedAstrologer from '@/components/Admin/ApprovedAstrologer'
import React from 'react'

const page = () => {
  return (
    <div>
      <ApprovedAstrologer/>
    </div>
  )
}

export default page
