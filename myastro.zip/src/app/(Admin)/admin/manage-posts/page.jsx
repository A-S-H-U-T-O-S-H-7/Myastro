import ManagePosts from '@/components/Admin/ManagePosts'
import React from 'react'

function page() {
  return (
    <div>
      <ManagePosts/>
    </div>
  )
}

export default page
