import ManageTransection from '@/components/Admin/ManageTransection'
import React from 'react'

function page() {
  return (
    <div>
      <ManageTransection/>
    </div>
  )
}

export default page
