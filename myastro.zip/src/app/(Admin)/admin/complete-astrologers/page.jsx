import CompleteAstrologer from '@/components/Admin/CompleteAstrologer'
import React from 'react'

function page() {
  return (
    <div>
     <CompleteAstrologer/> 
    </div>
  )
}

export default page
