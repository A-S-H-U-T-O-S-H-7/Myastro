import UserReview from '@/components/Admin/UserReview'
import React from 'react'

function page() {
  return (
    <div>
      <UserReview/>
    </div>
  )
}

export default page
