import AstrologerWallet from '@/components/Admin/AstrologerWallet'
import React from 'react'

function page() {
  return (
    <div>
      <AstrologerWallet/>
    </div>
  )
}

export default page
