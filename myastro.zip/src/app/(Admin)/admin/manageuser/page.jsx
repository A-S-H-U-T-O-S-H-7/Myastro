
import Manageuser from '@/components/Admin/Manageuser'
import React from 'react'


function page() {
  return (
    <div>
    <Manageuser/>
    </div>
  )
}

export default page
