import Notification from '@/components/Admin/Notification'
import React from 'react'

function page() {
  return (
    <div>
      <Notification/>
    </div>
  )
}

export default page
