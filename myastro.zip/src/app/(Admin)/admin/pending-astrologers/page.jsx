import PendingAstrologer from '@/components/Admin/PendingAstrologer'
import React from 'react'

function page() {
  return (
    <div>
      <PendingAstrologer/>
    </div>
  )
}

export default page
