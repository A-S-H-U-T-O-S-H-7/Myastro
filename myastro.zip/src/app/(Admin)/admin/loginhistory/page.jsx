import LoginHistory from '@/components/Admin/LoginHistory'
import React from 'react'

const page = () => {
  return (
    <div>
      <LoginHistory/>
    </div>
  )
}

export default page
