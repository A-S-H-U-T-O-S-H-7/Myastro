import React from 'react'
import IndivisualAstrologer from '@/components/IndivisualAstrologer'

function page() {
  return (
    <div>

      <IndivisualAstrologer/>
    </div>
  )
}

export default page
