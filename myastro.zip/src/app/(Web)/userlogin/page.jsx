import React from 'react'
import UserSignup from '@/components/UserSignup'

function page() {
  return (
    <div>
      <UserSignup/>
    </div>
  )
}

export default page
