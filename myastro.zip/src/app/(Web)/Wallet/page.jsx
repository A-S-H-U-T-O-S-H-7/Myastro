import WalletSection from '@/components/WalletSection'
import React from 'react'
import AstrologerForm from '@/components/AstrologerRegistration'

const page = () => {
  return (
    <div>
      <WalletSection/>
     <AstrologerForm/>
    </div>
  )
}

export default page
