import React from 'react'
import AstrologerForm from '@/components/AstrologerRegistration'

function page() {
  return (
    <div>
      <AstrologerForm/>
    </div>
  )
}

export default page
