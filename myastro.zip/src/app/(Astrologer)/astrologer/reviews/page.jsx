import Reviews from '@/components/Astrologer/Reviews'
import React from 'react'

function page() {
  return (
    <div>
      <Reviews/>
    </div>
  )
}

export default page
