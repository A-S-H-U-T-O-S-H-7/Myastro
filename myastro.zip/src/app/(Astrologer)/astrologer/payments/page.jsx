import PaymentDetails from '@/components/Astrologer/PaymentDetails'
import React from 'react'

function page() {
  return (
    <div>
      <PaymentDetails/>
    </div>
  )
}

export default page
