import React from 'react'
import CallHistory from '@/components/Astrologer/CallHistory'

function page() {
  return (
    <div>
      <CallHistory/>
    </div>
  )
}

export default page
