import Orders from '@/components/Astrologer/Orders'
import React from 'react'

function page() {
  return (
    <div>
      <Orders/>
    </div>
  )
}

export default page
