"use client"; // For Next.js 13+ with App Router
import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { FaUser, FaSms, FaBrain, FaUniversity, FaCloudUploadAlt } from "react-icons/fa";

export default function AstrologerForm() {
  const [step, setStep] = useState(1); // Progress stepper state
  const { register, handleSubmit,watch, formState: { errors }, trigger } = useForm();
  const [otpTimer, setOtpTimer] = useState(60); // 60-second timer for OTP
  const [isResendDisabled, setIsResendDisabled] = useState(true);
  const [isWorking, setIsWorking] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileError, setFileError] = useState("");
  const [wordCount, setWordCount] = useState(0);
  const [uploadedFields, setUploadedFields] = useState({});



  

// skills
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const allowedTypes = ["image/jpeg", "image/jpg", "image/png"];
      const maxSize = 2 * 1024 * 1024; // 2MB
      if (!allowedTypes.includes(file.type)) {
        setFileError("Only JPG, JPEG, or PNG files are allowed.");
        setSelectedFile(null);
      } else if (file.size > maxSize) {
        setFileError("File size should not exceed 2MB.");
        setSelectedFile(null);
      } else {
        setFileError("");
        setSelectedFile(file);
      }
    }
}


  // Function to start OTP timer
    useEffect(() => {
      let timer;
      if (otpTimer > 0) {
        timer = setInterval(() => setOtpTimer((prev) => prev - 1), 1000);
      } else {
        setIsResendDisabled(false);
        clearInterval(timer);
      }
      return () => clearInterval(timer);
    }, [otpTimer]);
  
    const handleResendOTP = () => {
      setOtpTimer(60); // Restart timer
      setIsResendDisabled(true);
    };

  // Function to handle form submission
  const onSubmit = (data) => {
    console.log(data);
    if (step < 6) {
      setStep(step + 1);
    } else {
      alert("Form Submitted Successfully!");
    }
  };

  // Function to handle "Next" button click with validation
  const handleNext = async () => {
    const isValid = await trigger(); // Validate current fields
    if (isValid) setStep(step + 1);
  };

  const steps = [
    { icon: <FaUser />, label: "Personal Details" },
    { icon: <FaSms />, label: "OTP Verify" },
    { icon: <FaBrain />, label: "Skill Details" },
    { icon: <FaBrain />, label: "Other Details" },
    { icon: <FaUniversity />, label: "Bank Details" },
    { icon: <FaCloudUploadAlt />, label: "Uploads" },
  ];

  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-purple-700 to-purple-900 px-4 py-6"
    >
      {/* Form Header */}
      <h1 className="text-3xl font-bold text-white mb-6 text-center">REGISTER NEW ASTROLOGER</h1>

     {/* Progress Bar */}
<div className="w-full max-w-4xl mb-12 px-3 mt-10 relative">
  {/* Progress Line */}
  <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-300 z-0" style={{ transform: "translateY(-50%)" }}>
    <div
      className="h-full bg-blue-500 transition-all duration-500"
      style={{ width: `${(step / 6) * 100}%` }}
    ></div>
  </div>

  {/* Step Icons and Labels */}
  <div className="relative z-10 flex justify-between items-center">
    {steps.map((item, index) => (
      <div
        key={index}
        className="relative flex flex-col items-center text-center"
        style={{
          position: "absolute",
          left: `${(index / (steps.length - 1)) * 100}%`,
          transform: "translateX(-50%)",
        }}
      >
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold transition-all duration-300 ${
            step >= index + 1
              ? "bg-blue-500 text-white"
              : "bg-gray-400 text-gray-800"
          }`}
        >
          {item.icon}
        </div>
        <p className="text-xs pl-4 lg:text-sm mt-2 text-white">{item.label}</p>
      </div>
    ))}
  </div>
</div>


      {/* Form */}
      <form
        onSubmit={handleSubmit(onSubmit)}
        
        className="w-full max-w-4xl bg-gradient-to-b from-white via-[#f8f4ff] to-[#eae0ff] shadow-lg rounded-lg p-8 space-y-6"
      >
        {/* Step 1: Personal Details */}
        {step === 1 && (
          <>
        <h2 className="text-lg font-bold text-center text-gray-800 mb-4">PERSONAL DETAILS</h2>

        {/* Full Name */}
        <div>
          <label className="block text-gray-700 font-semibold mb-1">
            Full Name<span className="text-red-500">*</span>
          </label>
          <input
            type="text"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Enter your full name"
            {...register("fullName", { required: "Full Name is required" })}
          />
          {errors.fullName && <p className="text-red-500 text-sm">{errors.fullName.message}</p>}
        </div>

        {/* Email */}
        <div>
          <label className="block text-gray-700 font-semibold mb-1">
            Email Id<span className="text-red-500">*</span>
          </label>
          <input
            type="email"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Enter your email id"
            {...register("email", {
              required: "Email is required",
              pattern: { value: /^\S+@\S+$/i, message: "Invalid email format" },
            })}
          />
          {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}
        </div>

        {/* Mobile Number */}
        <div>
          <label className="block text-gray-700 font-semibold mb-1">
            Mobile No.<span className="text-red-500">*</span>
          </label>
          <input
            type="tel"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Enter your mobile no."
            {...register("mobile", {
              required: "Mobile number is required",
              minLength: { value: 10, message: "Must be 10 digits" },
              maxLength: { value: 10, message: "Must be 10 digits" },

            })}
          />
          {errors.mobile && <p className="text-red-500 text-sm">{errors.mobile.message}</p>}
        </div>

        {/* WhatsApp Number */}
        <div>
          <label className="block text-gray-700 font-semibold mb-1">
            WhatsApp No.<span className="text-red-500">*</span>
          </label>
          <input
            type="tel"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder="Enter your WhatsApp no."
            {...register("whatsapp", { required: "WhatsApp number is required",
                minLength: { value: 10, message: "Must be 10 digits" },
              maxLength: { value: 10, message: "Must be 10 digits" },

             })}
          />
          {errors.whatsapp && <p className="text-red-500 text-sm">{errors.whatsapp.message}</p>}
        </div>

        {/* Terms and Conditions */}
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            {...register("terms", { required: "You must agree to the terms and conditions" })}
            className="focus:ring-2 focus:ring-purple-500"
          />
          <label className="text-gray-700 text-sm">
            I agree to the <span className="text-purple-600 font-semibold">Terms and Conditions</span>
            <span className="text-red-500">*</span>
          </label>
        </div>
        {errors.terms && <p className="text-red-500 text-sm">{errors.terms.message}</p>}

        {/* Next Button */}
        <div className="flex justify-end">
          <button
            type="button"
            onClick={handleNext}
            className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg transition-all duration-300"
          >
            {step === 5 ? "Submit" : "Next"}
          </button>
        </div>
        </>
        )}

        {/* Step 2: OTP Verification */}
          {step === 2 && (
          <>
            <h2 className="text-lg font-bold text-center text-gray-800 mb-4">OTP VERIFICATION</h2>
            <div>
              <label className="block text-gray-700 font-semibold mb-1">OTP<span className="text-red-500">*</span></label>
              <input
                type="text"
                maxLength="6"
                placeholder="Enter 6-digit OTP"
                className="w-full border rounded-lg px-4 py-2 text-center focus:outline-none focus:ring-2 focus:ring-purple-500"
                {...register("otp", { required: "OTP is required", minLength: 6, maxLength: 6 })}
              />
              {errors.otp && <p className="text-red-500 text-sm">{errors.otp.message}</p>}
            </div>
            <div className="flex items-center justify-between gap-4">
              <button
                type="button"
                onClick={handleResendOTP}
                disabled={isResendDisabled}
                className={`px-4 py-2 rounded ${
                  isResendDisabled ? "bg-gray-400 text-white" : "bg-blue-500 text-white hover:bg-blue-600"
                }`}
              >
                Resend OTP
              </button>
              <p className="text-gray-700 font-semibold">{isResendDisabled ? `Resend in ${otpTimer}s` : "Ready to resend"}</p>
            </div>
            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleNext}
                className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg"
              >
                Next
              </button>
            </div>
          </>
        )}


{/* Step 3: Skill Details */}
{step === 3 && (
  <>
    <h2 className="text-lg font-bold text-center text-gray-800 mb-6">
      SKILL DETAILS
    </h2>

    {/* Photo Upload */}
    <div className="mb-6">
      <label className="block text-gray-700 font-semibold mb-2">
        Upload Photo<span className="text-red-500">*</span>
      </label>
      <input
        type="file"
        accept=".jpg, .jpeg, .png"
        className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        {...register("photo", {
          required: "Photo is required",
          validate: (value) => {
            const file = value[0];
            if (!file) return "Photo is required";
            if (!["image/jpeg", "image/png", "image/jpg"].includes(file.type)) {
              return "Only jpg, jpeg, and png formats are allowed";
            }
            if (file.size > 2 * 1024 * 1024) {
              return "File size must be less than 2MB";
            }
            return true;
          },
        })}
      />
      <p className="text-sm text-gray-600 mt-1">
        Only jpg, jpeg, and png formats are allowed. Max size: 2MB. Passport-sized photo only.
      </p>
      {errors.photo && (
        <p className="text-red-500 text-sm">{errors.photo.message}</p>
      )}
    </div>

    {/* Astrologer Username */}
    <div className="mb-6">
      <label className="block text-gray-700 font-semibold mb-2">
        Astrologer Username<span className="text-red-500">*</span>
      </label>
      <input
        type="text"
        placeholder="Enter your username"
        className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        {...register("username", { required: "Username is required" })}
      />
      {errors.username && (
        <p className="text-red-500 text-sm">{errors.username.message}</p>
      )}
    </div>

    {/* Gender and DOB */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Gender<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("gender", { required: "Gender is required" })}
        >
          <option value="">Select</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
        {errors.gender && (
          <p className="text-red-500 text-sm">{errors.gender.message}</p>
        )}
      </div>

      

{/* Dob */}
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Date of Birth<span className="text-red-500">*</span>
        </label>
        <input
          type="date"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("dob", { required: "Date of Birth is required" })}
        />
        {errors.dob && (
          <p className="text-red-500 text-sm">{errors.dob.message}</p>
        )}
      </div>
    </div>


    {/* Country, State, City */}
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Country<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("country", { required: "Country is required" })}
        >
          <option value="india">India</option>
        </select>
      </div>
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          State<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("state", { required: "State is required" })}
        >
          <option value="">Select State</option>
          <option value="odisha">Odisha</option>
          {/* Add other states */}
        </select>
      </div>

      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          City<span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          placeholder="Enter your city"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("city", { required: "City is required" })}
        />
        {errors.city && (
          <p className="text-red-500 text-sm">{errors.city.message}</p>
        )}
      </div>
    </div>

    

    {/* Complete Address */}
    <div className="mb-6">
      <label className="block text-gray-700 font-semibold mb-2">
        Complete Address<span className="text-red-500">*</span>
      </label>
      <textarea
        rows="3"
        placeholder="Enter your full address"
        className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        {...register("address", { required: "Address is required" })}
      ></textarea>
      {errors.address && (
        <p className="text-red-500 text-sm">{errors.address.message}</p>
      )}
    </div>

    

    {/* Pincode */}
    <div className="mb-6">
      <label className="block text-gray-700 font-semibold mb-2">
        Pincode<span className="text-red-500">*</span>
      </label>
      <input
        type="text"
        placeholder="Enter 6-digit pincode"
        maxLength="6"
        className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        {...register("pincode", {
          required: "Pincode is required",
          pattern: {
            value: /^[0-9]{6}$/,
            message: "Pincode must be exactly 6 digits",
          },
        })}
      />
      {errors.pincode && (
        <p className="text-red-500 text-sm">{errors.pincode.message}</p>
      )}
    </div>
     {/* PAN */}
     <div>
            <label className="block font-semibold mb-1">PAN Number</label>
            <input
              type="text"
              placeholder="ABCDE1234F"
              pattern="^[A-Z]{5}[0-9]{4}[A-Z]{1}$"
              className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>
           {/* Aadhar */}
           <div>
            <label className="block font-semibold mb-1">Aadhar Number</label>
            <input
              type="text"
              pattern="^\d{12}$"
              placeholder="12-digit Aadhar"
              className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
              required
            />
          </div>
          {/* GST Number and Marital Status */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          GST Number (Optional)
        </label>
        <input
          type="text"
          placeholder="Enter GST Number"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("gstNumber", {
            pattern: {
              value: /^[0-9A-Z]{15}$/,
              message: "GST number must be 15 characters",
            },
          })}
        />
        {errors.gstNumber && (
          <p className="text-red-500 text-sm">{errors.gstNumber.message}</p>
        )}
      </div>
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Marital Status<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("maritalStatus", { required: "Marital status is required" })}
        >
          <option value="">Select</option>
          <option value="single">Single</option>
          <option value="married">Married</option>
        </select>
        {errors.maritalStatus && (
          <p className="text-red-500 text-sm">{errors.maritalStatus.message}</p>
        )}
      </div>
    </div>

    {/* Primary Skills, All Skills, and Languages */}
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Primary Skills<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("primarySkills", { required: "Primary skill is required" })}
        >
          <option value="">Select</option>
          <option value="vedic">Vedic</option>
          <option value="tarot">Tarot</option>
          <option value="numerology">Numerology</option>
        </select>
        {errors.primarySkills && (
          <p className="text-red-500 text-sm">{errors.primarySkills.message}</p>
        )}
      </div>

      {/* All Skills */}
<div className="mb-6">
  <label className="block text-gray-700 font-semibold mb-2">
    All Skills<span className="text-red-500">*</span>
  </label>
  <select
    multiple
    className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
    {...register("allSkills", {
      required: "At least one skill must be selected",
    })}
  >
    <option value="vedic">Vedic</option>
    <option value="tarot">Tarot</option>
    <option value="numerology">Numerology</option>
    <option value="palmistry">Palmistry</option>
    <option value="astrology">Astrology</option>
  </select>
  {errors.allSkills && (
    <p className="text-red-500 text-sm">{errors.allSkills.message}</p>
  )}
</div>

      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Languages
        </label>
        <select
          multiple
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("languages")}
        >
          <option value="english">English</option>
          <option value="hindi">Hindi</option>
          <option value="other">Other</option>
        </select>
      </div>
    </div>

    {/* Daily Contribution Hours and Experience */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Daily Contribution Hours<span className="text-red-500">*</span>
        </label>
        <input
          type="number"
          placeholder="Hours per day"
          min="0"
          max="20"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("dailyHours", {
            required: "Contribution hours are required",
            validate: (value) =>
              value > 20 ? "Cannot contribute more than 20 hours" : true,
          })}
        />
        {errors.dailyHours && (
          <p className="text-red-500 text-sm">{errors.dailyHours.message}</p>
        )}
      </div>

      <div>
        <label className="block text-gray-700 font-semibold mb-2">
          Experience (Years)<span className="text-red-500">*</span>
        </label>
        <input
          type="number"
          placeholder="Experience in years"
          max="99"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("experience", { required: "Experience is required" })}
        />
        {errors.experience && (
          <p className="text-red-500 text-sm">{errors.experience.message}</p>
        )}
      </div>
    </div>

    {/* Referral Source */}
    <div className="mb-6">
      <label className="block text-gray-700 font-semibold mb-2">
        Where did you hear about My Astro<span className="text-red-500">*</span>
      </label>
      <select
        className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
        {...register("referralSource", { required: "This field is required" })}
      >
        <option value="">Select</option>
        <option value="youtube">YouTube</option>
        <option value="facebook">Facebook</option>
        <option value="instagram">Instagram</option>
      </select>
      {errors.referralSource && (
        <p className="text-red-500 text-sm">{errors.referralSource.message}</p>
      )}
    </div>



            {/* Working on Other Platforms */}
            <div className="col-span-2">
            <label className="block font-semibold mb-2">Are you working on another online platform?</label>
            <div className="flex gap-4">
              <label>
                <input
                  type="radio"
                  value="yes"
                  onChange={() => setIsWorking(true)}
                />{" "}
                Yes
              </label>
              <label>
                <input
                  type="radio"
                  value="no"
                  onChange={() => setIsWorking(false)}
                />{" "}
                No
              </label>
            </div>
            {isWorking && (
              <input
                type="text"
                placeholder="Enter platform name"
                className="w-full mt-2 border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            )}
          </div>
        

    {/* Next Button */}
    <div className="flex justify-end">
      <button
        type="button"
        onClick={handleNext}
        className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg transition-all duration-300"
      >
        Next
      </button>
    </div>
  </>
)}

{/* other details */}
{step === 4 && (
  <>
    <h2 className="text-lg font-bold text-center text-gray-800 mb-4">Work Preferences</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {/* Why do you think we should onboard you? */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Why do you think we should onboard you?<span className="text-red-500">*</span>
        </label>
        <textarea
          rows="3"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Tell us why..."
          {...register("onboardingReason", { required: "This field is required" })}
        />
        {errors.onboardingReason && <p className="text-red-500 text-sm">{errors.onboardingReason.message}</p>}
      </div>

      {/* Main source of income */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Main source of income (other than astrology)?<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("mainIncomeSource", { required: "This field is required" })}
        >
          <option value="">Select an option</option>
          <option value="privateJob">Private Job</option>
          <option value="govtJob">Government Job</option>
          <option value="business">Business</option>
        </select>
        {errors.mainIncomeSource && <p className="text-red-500 text-sm">{errors.mainIncomeSource.message}</p>}
      </div>

      {/* Highest qualification */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Select your highest qualification:<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("highestQualification", { required: "This field is required" })}
        >
          <option value="">Select an option</option>
          <option value="10th">10th</option>
          <option value="12th">12th</option>
          <option value="graduate">Graduate</option>
          <option value="postGraduate">Post Graduate</option>
        </select>
        {errors.highestQualification && <p className="text-red-500 text-sm">{errors.highestQualification.message}</p>}
      </div>

      {/* Where did you learn Astrology? */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          From where did you learn Astrology?<span className="text-red-500">*</span>
        </label>
        <textarea
          rows="2"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Share your source of learning"
          {...register("astrologyLearningSource", { required: "This field is required" })}
        />
        {errors.astrologyLearningSource && <p className="text-red-500 text-sm">{errors.astrologyLearningSource.message}</p>}
      </div>

      {/* Social Media Links */}
      {["Instagram", "Facebook", "LinkedIn", "YouTube", "Website"].map((platform) => (
        <div className="col-span-1" key={platform}>
          <label className="block text-gray-700 font-semibold mb-1">
            {platform} profile link (optional):
          </label>
          <input
            type="url"
            className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
            placeholder={`Enter ${platform.toLowerCase()} profile link`}
            {...register(`${platform.toLowerCase()}Profile`)}
          />
        </div>
      ))}

      {/* Referred by someone */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Did anybody refer you to Myastro?<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("referredBy", { required: "This field is required" })}
        >
          <option value="">Select an option</option>
          <option value="yes">Yes</option>
          <option value="no">No</option>
        </select>
        {errors.referredBy && <p className="text-red-500 text-sm">{errors.referredBy.message}</p>}
      </div>

      {/* Minimum charges per minute */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Minimum charges per minute from customer:<span className="text-red-500">*</span>
        </label>
        <input
          type="number"
          max="50"
          min="1"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Enter amount (max: 50)"
          {...register("minimumCharges", {
            required: "This field is required",
            validate: (value) => value <= 50 || "Must not exceed 50",
          })}
        />
        {errors.minimumCharges && <p className="text-red-500 text-sm">{errors.minimumCharges.message}</p>}
      </div>

      {/* Minimum Monthly Earning Expectation */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Minimum Monthly Earning Expectation from Myastro:<span className="text-red-500">*</span>
        </label>
        <input
          type="number"
          max="99999"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Enter expected earnings"
          {...register("monthlyEarnings", {
            required: "This field is required",
            maxLength: { value: 5, message: "Must not exceed 5 digits" },
          })}
        />
        {errors.monthlyEarnings && <p className="text-red-500 text-sm">{errors.monthlyEarnings.message}</p>}
      </div>

      {/* Are you currently working full-time? */}
      <div className="col-span-1">
        <label className="block text-gray-700 font-semibold mb-1">
          Are you currently working a full-time job?<span className="text-red-500">*</span>
        </label>
        <select
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("fullTimeJob", { required: "This field is required" })}
        >
          <option value="">Select an option</option>
          <option value="yes">Yes</option>
          <option value="no">No</option>
        </select>
        {errors.fullTimeJob && <p className="text-red-500 text-sm">{errors.fullTimeJob.message}</p>}
      </div>

      {/* Long Bio with Word Count */}
      <div className="col-span-2">
        <label className="block text-gray-700 font-semibold mb-1">
          Long Bio:<span className="text-red-500">*</span>
        </label>
        <textarea
          rows="4"
          className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          placeholder="Type at least 50 words"
          {...register("longBio", {
            required: "This field is required",
            validate: (value) => value.trim().split(/\s+/).length >= 50 || "Minimum 50 words required",
          })}
          onChange={(e) => setWordCount(e.target.value.trim().split(/\s+/).length)}
        />
        <p className="text-gray-600 text-sm">Word Count: {wordCount}</p>
        {errors.longBio && <p className="text-red-500 text-sm">{errors.longBio.message}</p>}
      </div>
    </div>

    {/* Next Button */}
    <div className="flex justify-end mt-4">
      <button
        type="button"
        onClick={handleNext}
        className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg"
      >
        Next
      </button>
    </div>
  </>
)}

{/* Bank details */}
{step === 5 && (
  <>
    <h2 className="text-lg font-bold text-center text-gray-800 mb-4">Bank Details</h2>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

      {/* IFSC Code */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">IFSC Code<span className="text-red-500">*</span></label>
        <input
          type="text"
          placeholder="Enter IFSC Code"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("ifsc", { required: "IFSC Code is required" })}
        />
        {errors.ifsc && <p className="text-red-500 text-sm">{errors.ifsc.message}</p>}
      </div>

      {/* Bank Name */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">Bank Name<span className="text-red-500">*</span></label>
        <input
          type="text"
          placeholder="Enter Bank Name"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("bankName", { required: "Bank Name is required" })}
        />
        {errors.bankName && <p className="text-red-500 text-sm">{errors.bankName.message}</p>}
      </div>

      {/* Bank Branch */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">Bank Branch<span className="text-red-500">*</span></label>
        <input
          type="text"
          placeholder="Enter Bank Branch"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("bankBranch", { required: "Bank Branch is required" })}
        />
        {errors.bankBranch && <p className="text-red-500 text-sm">{errors.bankBranch.message}</p>}
      </div>

      {/* Account Type */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">Account Type<span className="text-red-500">*</span></label>
        <select
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("accountType", { required: "Account Type is required" })}
        >
          <option value="">Select Account Type</option>
          <option value="savings">Savings</option>
          <option value="current">Current</option>
        </select>
        {errors.accountType && <p className="text-red-500 text-sm">{errors.accountType.message}</p>}
      </div>

      {/* Account Number */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">Account Number<span className="text-red-500">*</span></label>
        <input
          type="text"
          placeholder="Enter Account Number"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("accountNumber", { required: "Account Number is required" })}
        />
        {errors.accountNumber && <p className="text-red-500 text-sm">{errors.accountNumber.message}</p>}
      </div>

      {/* Confirm Account Number */}
      <div>
        <label className="block text-gray-700 font-semibold mb-1">Confirm Account Number<span className="text-red-500">*</span></label>
        <input
          type="text"
          placeholder="Confirm Account Number"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("confirmAccountNumber", {
            required: "Please confirm your account number",
            validate: (value) => value === watch("accountNumber") || "Account numbers do not match"
          })}
        />
        {errors.confirmAccountNumber && <p className="text-red-500 text-sm">{errors.confirmAccountNumber.message}</p>}
      </div>

      {/* Bank UPI ID */}
      <div className="md:col-span-2">
        <label className="block text-gray-700 font-semibold mb-1">Bank UPI ID (Optional)</label>
        <input
          type="text"
          placeholder="Enter UPI ID"
          className="w-full border rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-purple-500"
          {...register("upiId")}
        />
      </div>
    </div>

    {/* Next Button */}
    <div className="flex justify-end mt-6">
      <button
        type="button"
        onClick={handleNext}
        className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg"
      >
        Next
      </button>
    </div>
  </>
)}

{/* upload documents */}
{step === 6 && (
        <>
          <h2 className="text-lg font-bold text-center text-gray-800 mb-4">
            Upload Documents
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

            {/* Astrology Certificate */}
            <div>
              <label className="block text-gray-700 font-semibold mb-1">
                Astrology Certificate<span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  {...register("astrologyCertificate", {
                    required: "Astrology Certificate is required",
                    validate: {
                      size: (file) =>
                        file?.[0]?.size <= 2 * 1024 * 1024 ||
                        "File must be less than 2MB",
                    },
                  })}
                  onChange={(e) => handleFileChange("astrologyCertificate", e)}
                />
                <div
                  className={`w-full border rounded-lg px-4 py-2 ${
                    uploadedFields.astrologyCertificate
                      ? "bg-green-200 text-gray-800"
                      : "bg-white text-gray-600"
                  } cursor-pointer`}
                >
                  {uploadedFields.astrologyCertificate
                    ? "Uploaded"
                    : "Upload Astrology Certificate"}
                </div>
              </div>
              {errors.astrologyCertificate && (
                <p className="text-red-500 text-sm">
                  {errors.astrologyCertificate.message}
                </p>
              )}
            </div>

            {/* PAN Card */}
            <div>
              <label className="block text-gray-700 font-semibold mb-1">
                PAN Card<span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  {...register("panCard", {
                    required: "PAN Card is required",
                    validate: {
                      size: (file) =>
                        file?.[0]?.size <= 2 * 1024 * 1024 ||
                        "File must be less than 2MB",
                    },
                  })}
                  onChange={(e) => handleFileChange("panCard", e)}
                />
                <div
                  className={`w-full border rounded-lg px-4 py-2 ${
                    uploadedFields.panCard
                      ? "bg-green-200 text-gray-800"
                      : "bg-white text-gray-600"
                  } cursor-pointer`}
                >
                  {uploadedFields.panCard ? "Uploaded" : "Upload PAN Card"}
                </div>
              </div>
              {errors.panCard && (
                <p className="text-red-500 text-sm">{errors.panCard.message}</p>
              )}
            </div>

            {/* Aadhaar Back */}
            <div>
              <label className="block text-gray-700 font-semibold mb-1">
                Aadhaar Back<span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  {...register("aadhaarBack", {
                    required: "Aadhaar Back is required",
                    validate: {
                      size: (file) =>
                        file?.[0]?.size <= 2 * 1024 * 1024 ||
                        "File must be less than 2MB",
                    },
                  })}
                  onChange={(e) => handleFileChange("aadhaarBack", e)}
                />
                <div
                  className={`w-full border rounded-lg px-4 py-2 ${
                    uploadedFields.aadhaarBack
                      ? "bg-green-200 text-gray-800"
                      : "bg-white text-gray-600"
                  } cursor-pointer`}
                >
                  {uploadedFields.aadhaarBack
                    ? "Uploaded"
                    : "Upload Aadhaar Back"}
                </div>
              </div>
              {errors.aadhaarBack && (
                <p className="text-red-500 text-sm">
                  {errors.aadhaarBack.message}
                </p>
              )}
            </div>

            {/* Aadhaar Front */}
            <div>
              <label className="block text-gray-700 font-semibold mb-1">
                Aadhaar Front<span className="text-red-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  {...register("aadhaarFront", {
                    required: "Aadhaar Front is required",
                    validate: {
                      size: (file) =>
                        file?.[0]?.size <= 2 * 1024 * 1024 ||
                        "File must be less than 2MB",
                    },
                  })}
                  onChange={(e) => handleFileChange("aadhaarFront", e)}
                />
                <div
                  className={`w-full border rounded-lg px-4 py-2 ${
                    uploadedFields.aadhaarFront
                      ? "bg-green-200 text-gray-800"
                      : "bg-white text-gray-600"
                  } cursor-pointer`}
                >
                  {uploadedFields.aadhaarFront
                    ? "Uploaded"
                    : "Upload Aadhaar Front"}
                </div>
              </div>
              {errors.aadhaarFront && (
                <p className="text-red-500 text-sm">
                  {errors.aadhaarFront.message}
                </p>
              )}
            </div>

            {/* Biodata (Optional) */}
            <div className="md:col-span-2">
              <label className="block text-gray-700 font-semibold mb-1">
                Biodata (Optional)
              </label>
              <div className="relative">
                <input
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  {...register("biodata", {
                    validate: {
                      size: (file) =>
                        !file?.[0] ||
                        file?.[0]?.size <= 2 * 1024 * 1024 ||
                        "File must be less than 2MB",
                    },
                  })}
                  onChange={(e) => handleFileChange("biodata", e)}
                />
                <div
                  className={`w-full border rounded-lg px-4 py-2 ${
                    uploadedFields.biodata
                      ? "bg-green-200 text-gray-800"
                      : "bg-white text-gray-600"
                  } cursor-pointer`}
                >
                  {uploadedFields.biodata ? "Uploaded" : "Upload Biodata"}
                </div>
              </div>
              {errors.biodata && (
                <p className="text-red-500 text-sm">{errors.biodata.message}</p>
              )}
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end mt-6">
            <button
              type="submit"
              className="bg-[#9b57ed] hover:bg-purple-600 text-white px-6 py-2 rounded-lg"
            >
              Submit
            </button>
          </div>
        </>
      )}





      </form>
    </div>
  );
}
